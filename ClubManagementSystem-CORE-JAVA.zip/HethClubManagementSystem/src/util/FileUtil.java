package util;

import java.io.File;

	public class FileUtil {

	    public static boolean fileExists(String filename) {
	        File file = new File(filename);
	        return file.exists();
	    }
	}

