package Menu;

import model.Member;
import service.ClubService;
import service.ClubServiceImpl;
import util.FileUtil;

import java.util.List;
import java.util.Scanner;

public class Menu {
    private ClubService clubService;
    private Scanner scanner;

    public Menu() {
        clubService = new ClubServiceImpl();
        scanner = new Scanner(System.in);
        // Load members from file if it exists
        if (FileUtil.fileExists("members.dat")) {
            clubService.loadMembersFromFile("members.dat");
        }
    }

    public void displayMenu() {
        String option;
        do {
            System.out.println("1. Add Member");
            System.out.println("2. Remove Member");
            System.out.println("3. List Members");
            System.out.println("4. Save Members");
            System.out.println("5. Load Members");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            option = scanner.nextLine();

            switch (option) {
                case "1":
                    addMember();
                    break;
                case "2":
                    removeMember();
                    break;
                case "3":
                    listMembers();
                    break;
                case "4":
                    saveMembers();
                    break;
                case "5":
                    loadMembers();
                    break;
                case "6":
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
                    break;
            }
        } while (!option.equals("6"));
    }

    private void addMember() {
        System.out.print("Enter member ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter member name: ");
        String name = scanner.nextLine();
        System.out.print("Enter member email: ");
        String email = scanner.nextLine();
        Member member = new Member(id, name, email);
        clubService.addMember(member);
        System.out.println("Member added: " + member);
    }

    private void removeMember() {
        System.out.print("Enter member ID to remove: ");
        String id = scanner.nextLine();
        clubService.removeMember(id);
        System.out.println("Member with ID " + id + " removed.");
    }

    private void listMembers() {
        List<Member> members = clubService.listMembers();
        if (members.isEmpty()) {
            System.out.println("No members in the club.");
        } else {
            System.out.println("Club Members:");
            for (Member member : members) {
                System.out.println(member);
            }
        }
    }

    private void saveMembers() {
        boolean success = clubService.saveMembersToFile("members.dat");
        if (success) {
            System.out.println("Members saved to file.");
        } else {
            System.out.println("Failed to save members.");
        }
    }

    private void loadMembers() {
        boolean success = clubService.loadMembersFromFile("members.dat");
        if (success) {
            System.out.println("Members loaded from file.");
        } else {
            System.out.println("Failed to load members.");
        }
    }
}
