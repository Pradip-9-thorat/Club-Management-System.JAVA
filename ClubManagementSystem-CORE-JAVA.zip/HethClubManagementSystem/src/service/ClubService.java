package service;
import model.Member;
import java.util.List;

	public interface ClubService {
	    void addMember(Member member);
	    void removeMember(String id);
	    List<Member> listMembers();
	    boolean saveMembersToFile(String filename);
	    boolean loadMembersFromFile(String filename);
	}

