package service;

import model.Member;
import util.FileUtil;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

	public class ClubServiceImpl implements ClubService {
	    private List<Member> members;

	    public ClubServiceImpl() {
	        members = new ArrayList<>();
	    }

	    @Override
	    public void addMember(Member member) {
	        members.add(member);
	    }

	    @Override
	    public void removeMember(String id) {
	        members.removeIf(member -> member.getId().equals(id));
	    }

	    @Override
	    public List<Member> listMembers() {
	        return new ArrayList<>(members);
	    }

	    @Override
	    public boolean saveMembersToFile(String filename) {
	        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
	            oos.writeObject(members);
	            return true;
	        } catch (IOException e) {
	            e.printStackTrace();
	            return false;
	        }
	    }

	    @Override
	    public boolean loadMembersFromFile(String filename) {
	        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
	            members = (List<Member>) ois.readObject();
	            return true;
	        } catch (IOException | ClassNotFoundException e) {
	            e.printStackTrace();
	            return false;
	        }
	    }
	}
